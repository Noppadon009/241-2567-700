#include <PubSubClient.h>
#include <WiFi.h>
#include <DHT.h>

#define DHTPIN 15
#define DHTPIN 27
#define DHTTYPE DHT22
#define LED_RED_PIN 26
#define LED_GREEN_PIN 12

DHT dht(DHTPIN, DHTTYPE);

const char* ssid = "Wokwi-GUEST";
const char* password = "";

WiFiClient wifiClient;
const char* mqttServer = "broker.hivemq.com";
const int mqttPort = 1883;
const char* topic_pub = "ITKPS/Lab/bm";
PubSubClient mqttClient(wifiClient);

float temperature, humidity;
String publishMessage;

void setup_wifi() {
  Serial.println("Connecting to WiFi...");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected!");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
}

void reconnectMQTT() {
  while (!mqttClient.connected()) {
    Serial.println("Connecting to MQTT Broker...");
    if (mqttClient.connect("ESP32Client")) {
      Serial.println("Connected to MQTT Broker!");
    } else {
      Serial.print("Failed, rc=");
      Serial.print(mqttClient.state());
      Serial.println(" Retrying in 5 seconds...");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  dht.begin();

  setup_wifi();
  mqttClient.setServer(mqttServer, mqttPort);

  pinMode(LED_RED_PIN, OUTPUT);
  pinMode(LED_GREEN_PIN, OUTPUT);

  digitalWrite(LED_RED_PIN, LOW);
  digitalWrite(LED_GREEN_PIN, LOW);
}

void controlLEDs(float temp) {
  if (temp > 30.0) {
    digitalWrite(LED_RED_PIN, HIGH);
    digitalWrite(LED_GREEN_PIN, LOW);
  } else {
    digitalWrite(LED_RED_PIN, LOW);
    digitalWrite(LED_GREEN_PIN, HIGH);
  }
}

void loop() {
  if (!mqttClient.connected()) {
    reconnectMQTT();
  }
  mqttClient.loop();

  temperature = dht.readTemperature();
  humidity = dht.readHumidity();

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Failed to read from DHT sensor!");
    return;
  }

  controlLEDs(temperature);

  publishMessage = "Temperature: " + String(temperature) + "°C, Humidity: " + String(humidity) + "%";
  mqttClient.publish(topic_pub, publishMessage.c_str());

  Serial.println(publishMessage);

  delay(2000);
}